import CompanyList from "../../CouponologyArea/CompanyList/CompanyList";
import "./ComapnyInformation.css";

function ComapnyInformation(): JSX.Element {
    return (
        <div className="ComapnyInformation flex-center">
			<CompanyList/>
        </div>
    );
}

export default ComapnyInformation;
