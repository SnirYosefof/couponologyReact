import "./RoungClient.css";

function RoungClient(): JSX.Element {
    return (
        <div className="RoungClient flex-col-center">
			<h1>pooya you not allowed to get this information. the website admin get your details. </h1>
            <iframe width="560" height="315" src="https://www.youtube.com/embed/0aoNAe3BhAg?start=19" title="YouTube video player" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen></iframe>     
               </div>
    );
}

export default RoungClient;
