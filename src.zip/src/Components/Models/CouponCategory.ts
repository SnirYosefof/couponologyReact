export enum CouponCategory{
    FOOD="FOOD",
    SHOW="SHOW",
    ELECTRONICS="ELECTRONICS",
    VACATIONS="VACATIONS"
    
}